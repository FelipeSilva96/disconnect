export { RegisterPage } from "./Register";
