export { SearchPage } from "./Search";
